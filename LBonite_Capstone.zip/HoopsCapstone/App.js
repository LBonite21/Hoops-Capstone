import { StatusBar } from 'expo-status-bar';
import React from 'react';
import Hoops from './src/components/Hoops';

export default function App() {
  return (
   <Hoops />
  );
}

